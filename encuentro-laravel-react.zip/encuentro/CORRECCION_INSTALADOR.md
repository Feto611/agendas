# Error «Could not open input file: artisan»

El paquete contiene `artisan` en su raíz. El Dockerfile establece `/var/www/html` y ejecuta `package:discover` durante la construcción. Si esa construcción termina correctamente y después falla `php artisan`, hace falta revisar la imagen y la configuración efectiva del servidor para confirmar la causa.

Esta revisión fija `working_dir` en los cinco servicios PHP y utiliza `/var/www/html/artisan` en los comandos. El instalador verifica los archivos locales, valida Compose y comprueba que `artisan` y `vendor/autoload.php` sean legibles dentro de la imagen antes de iniciar PostgreSQL o migrar.

## Instalar o actualizar

Sustituye los archivos del proyecto completo, conservando `.env` y los volúmenes existentes. No generes otra APP_KEY ni borres la base de datos. Desde la carpeta que contiene `artisan`, `compose.yaml` e `install.sh`:

```bash
bash install.sh
```

El instalador utiliza únicamente `compose.yaml` y `.env` de su propia carpeta. No carga automáticamente `compose.override.yaml` ni `COMPOSE_FILE`. Si tu despliegue necesita archivos adicionales, como `compose.https.yaml`, revisa y aplica esa configuración de forma explícita: el instalador base no la incorpora. Conserva el nombre de proyecto de tu instalación y sus volúmenes. Esta revisión no añade migraciones.

## Si persiste

Comprueba los archivos de la imagen sin realizar migraciones y comparte la salida:

```bash
docker compose -f compose.yaml run --rm --no-deps --workdir /var/www/html --entrypoint sh app -c 'pwd; ls -l /var/www/html/artisan /var/www/html/vendor/autoload.php'
```

Si faltan archivos, revisa el paquete extraído, el target `app` construido y los montajes que puedan ocultar el código. El mensaje aislado no permite distinguir estas causas.

## Validación y referencias

Las siete pruebas de flujo del instalador sustituyen Docker por un stub. Comprueban conservación de claves, preparación sin PHP del host, detención ante fallos, rutas explícitas y selección del archivo Compose. No equivalen a una construcción Docker real ni a una validación del servidor remoto.

Documentación oficial: [selección de archivos Compose](https://docs.docker.com/reference/cli/docker/compose/), [run y --workdir](https://docs.docker.com/reference/cli/docker/compose/run/), [working_dir de los servicios](https://docs.docker.com/reference/compose-file/services/).
