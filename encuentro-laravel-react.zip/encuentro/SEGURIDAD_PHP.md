# Actualización PHP contra php2shell — 31 de octubre de 2026

La imagen de aplicación utiliza la etiqueta móvil `php:8.3-fpm-alpine`; el instalador usa `php:8.3-cli-alpine` cuando no hay PHP local. Al reconstruir con `--pull` se descarga la imagen disponible de la rama 8.3, sin cambiar a 8.4 o 8.5. Los contenedores en ejecución no se actualizan por sí solos. Se exige como mínimo PHP 8.3.36, versión corregida para CVE-2026-109618 y CVE-2026-109619.

También se desactiva `session.upload_progress.enabled` en la configuración PHP y se impone mediante `php_admin_flag` en el pool FPM para mitigar CVE-2026-115560. Laravel conserva sus sesiones y las subidas normales; esta plataforma no usa el seguimiento nativo de progreso de subidas de PHP.

La construcción comprueba la versión mínima, la mitigación y la sintaxis de FPM. Todos los procesos PHP de Compose comparten esta imagen: app, app-owner, scheduler, reverb y realtime-worker. El instalador construye con `--pull`. Composer no actualiza el intérprete: su versión de plataforma es una referencia de dependencias, no la versión que ejecuta Docker.

## Aplicar a una instalación existente

Sustituye los archivos del proyecto conservando `.env` y los volúmenes. No regeneres APP_KEY. Esta revisión no agrega migraciones ni cambia credenciales.

```bash
cd ~/agendavirtual/encuentro
docker compose build --pull --no-cache
docker compose up -d --no-deps --force-recreate app app-owner scheduler reverb realtime-worker web web-owner
docker compose exec -T app php artisan optimize:clear
docker compose exec -T app-owner php artisan optimize:clear
```

La recreación reinicia brevemente los servicios. Si la construcción falla, corrige el error antes de recrearlos; no elimines los volúmenes ni utilices una imagen PHP anterior como alternativa.

## Comprobar después de desplegar

```bash
for servicio in app app-owner scheduler reverb realtime-worker; do
  docker compose exec -T "$servicio" php /usr/local/bin/check-php-security.php || break
done
docker compose exec -T app php-fpm -tt
docker compose exec -T app-owner php-fpm -tt
```

El primer comando debe mostrar PHP 8.3.36 o una revisión posterior de la rama 8.3 y `session.upload_progress.enabled=Off` en los cinco servicios. Las comprobaciones FPM deben mostrar el valor administrativo de esa directiva desactivado y una configuración válida. No publiques phpinfo ni el comprobador como una ruta web.

Prueba inicio de sesión, subida de una fotografía y apertura del checkout después del reinicio. La actualización del paquete no demuestra que un servidor previamente expuesto esté libre de una intrusión anterior.

Cloudflare WAF añade protección para solicitudes que pasan por su proxy, pero no sustituye el parche del intérprete. No se ha cambiado tu cuenta Cloudflare ni tu servidor desde esta entrega. Si ejecutas PHP fuera de Docker, actualiza también ese intérprete y su configuración con los paquetes de tu distribución.

## Fuentes y alcance de validación

- PHP, avisos del 21 y 23 de octubre: https://www.php.net/archive/2026.php
- Cloudflare: https://blog.cloudflare.com/php-vulnerabilities-waf-protection/

Las etiquetas móviles sustituyen a las etiquetas 8.3.36 de la revisión anterior; se conserva la comprobación de versión mínima y la mitigación de subidas. En el entorno de preparación no hay Docker: no se pudo construir ni arrancar la imagen corregida. Las comprobaciones locales de aplicación se ejecutan con PHP 8.3.6 y la mitigación activada; verifican regresiones de aplicación, no la corrección binaria del intérprete. Se verificó además que el comprobador rechaza este intérprete anterior al parche. La versión definitiva y FPM deben verificarse con los comandos anteriores en tu servidor.
