<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
 Schema::create('venue_members',function(Blueprint $t){$t->id();$t->foreignId('venue_id')->constrained()->cascadeOnDelete();$t->foreignId('owner_id')->constrained('owners')->cascadeOnDelete();$t->json('permissions');$t->timestamps();$t->unique(['venue_id','owner_id']);});
 Schema::create('audit_events',function(Blueprint $t){$t->id();$t->foreignId('venue_id')->nullable()->index();$t->string('actor_type',20);$t->string('actor_label',100);$t->unsignedBigInteger('actor_id')->nullable();$t->string('event',100);$t->string('subject',150);$t->json('changes');$t->timestamp('created_at')->index();});
 Schema::create('reschedule_requests',function(Blueprint $t){$t->uuid('id')->primary();$t->foreignUuid('booking_id')->constrained()->cascadeOnDelete();$t->string('status',20)->default('pending')->index();$t->text('proposal');$t->string('original_version',64);$t->foreignId('decided_by')->nullable()->constrained('owners');$t->timestamps();});
 Schema::create('operation_settings',function(Blueprint $t){$t->foreignId('venue_id')->primary()->constrained()->cascadeOnDelete();$t->boolean('reminders_enabled')->default(false);$t->boolean('alerts_enabled')->default(false);$t->timestamps();});
 Schema::create('operation_messages',function(Blueprint $t){$t->uuid('id')->primary();$t->foreignId('venue_id')->constrained()->cascadeOnDelete();$t->foreignUuid('booking_id')->nullable()->constrained()->cascadeOnDelete();$t->string('dedup_key',64)->unique();$t->string('kind',30);$t->string('provider_id',200)->nullable();$t->string('status',20)->default('pending')->index();$t->text('payload');$t->timestamp('sent_at')->nullable();$t->timestamps();});
 Schema::create('operation_heartbeats',function(Blueprint $t){$t->string('name',40)->primary();$t->timestamp('seen_at');});
 }
 public function down():void {foreach(['operation_heartbeats','operation_messages','operation_settings','reschedule_requests','audit_events','venue_members'] as $name)Schema::dropIfExists($name);}
};
