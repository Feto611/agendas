# Estilo original en crema — 4 de noviembre de 2026

Se recupera la distribución anterior del catálogo y de la página del establecimiento. Se retiran la portada destacada repetida, los bloques de pasos y las llamadas a la acción adicionales de la propuesta editorial. El título y los textos siguen configurados mediante Identidad de página.

## Paleta

- Fondo crema: #f8f3ea.
- Superficies blanco cálido: #fffcf7.
- Texto café oscuro: #40352d.
- Botones nogal: #76543b, con texto blanco.
- Texto secundario: #716457.
- Bordes y fondos secundarios beige.

Los colores verdes de la hoja de estilos se sustituyen por tonos cálidos; se conservan los colores de advertencias, errores y medios de pago cuando son necesarios para reconocer su significado. Los campos usan texto de 16 px en celular.

La paleta predeterminada del editor pasa a crema y nogal. Las configuraciones que conservan exactamente los antiguos colores base se muestran con la nueva paleta mediante una conversión de presentación; no se reescriben registros al visitar la página. Las elecciones personalizadas diferentes se conservan y pueden cambiarse en Diseño y vista previa.

Las fotografías, precios, reglas, reservas y personalización del nombre/logo siguen utilizando los datos del negocio. No se añaden textos comerciales ni reseñas inventadas.

## Aplicar

Conserva .env, APP_KEY y los volúmenes. Sustituye los archivos incluyendo composer.lock. Para actualizar:

```bash
docker compose build --pull
docker compose up -d
docker compose exec -T app php artisan optimize:clear
docker compose exec -T app-owner php artisan optimize:clear
```

No se agregan migraciones. El paquete conserva symfony/mime 7.4.22. La imagen de muestra, si acompaña la entrega, es ilustrativa y no representa una fotografía real del local ni una captura del sitio publicado.
