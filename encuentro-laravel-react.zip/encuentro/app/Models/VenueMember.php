<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class VenueMember extends Model {protected $guarded=[];protected function casts():array{return ['permissions'=>'array','owner_id'=>'integer','venue_id'=>'integer'];}}
