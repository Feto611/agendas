<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class RescheduleRequest extends Model {public $incrementing=false;protected $keyType='string';protected $guarded=[];protected function casts():array{return ['proposal'=>'encrypted:array'];}public function booking(){return $this->belongsTo(Booking::class);}}
