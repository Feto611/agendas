<?php
namespace App\Services;
use Illuminate\Database\Eloquent\Model;use Illuminate\Support\Facades\DB;
class AuditTrail {
 public static function record(?int $venue,string $event,string $subject,array $changes=[]):void {
 if(!\Illuminate\Support\Facades\Schema::hasTable('audit_events'))return;
 $actor=app()->bound('request')&&request()->route()?request()->user():null;
 DB::table('audit_events')->insert(['venue_id'=>$venue,'actor_type'=>$actor instanceof \App\Models\Owner?'owner':($actor?'customer':'system'),'actor_label'=>$actor?->name??'Sistema','actor_id'=>$actor?->id,'event'=>$event,'subject'=>$subject,'changes'=>json_encode($changes,JSON_THROW_ON_ERROR),'created_at'=>now()]);
 }
 public function created(Model $m):void {$this->changed($m,true);}
 public function updated(Model $m):void {$this->changed($m,false);}
 private function changed(Model $m,bool $created):void {
 if(!$created&&!$m->wasChanged())return;
 $fields=match(class_basename($m)){'Venue'=>['name','published','settings'],'Booking'=>['status','starts_at','ends_at','total','deposit','expires_at'],'BookingPayment'=>['amount','method','reference'],'GatewayAccount'=>['enabled','sandbox','current'],'VenueMailAccount'=>['provider','enabled'],'Owner'=>['activated','platform_admin'],'VenueMember'=>['permissions'],'OperationMessage'=>['status'],default=>[]};
 $changes=[];foreach($fields as $field){if(!$created&&!$m->wasChanged($field))continue;$before=$m->getOriginal($field);$after=$m->getAttribute($field);
 if($field==='settings'){$allowed=array_flip(['weekday_price','weekend_price','holiday_price','extra_hour_price','deposit_type','deposit_value','capacity','open_hour','close_hour','open_minute','close_minute','prep_minutes','clean_minutes','rules','closed_weekdays']);$before=array_intersect_key((array)$before,$allowed);$after=array_intersect_key((array)$after,$allowed);}
 if($field==='reference'){$before=$before?'[registrada]':null;$after=$after?'[registrada]':null;}
 if($before!=$after)$changes[$field]=['before'=>$before,'after'=>$after];}
 foreach(['credentials','ai_key','wifi_credentials','design','design_draft'] as $field)if(array_key_exists($field,$m->getAttributes())&&($created||$m->wasChanged($field)))$changes[$field]=['changed'=>true,'values'=>'[omitidos]'];
 if(!$changes)return;$venue=$m instanceof \App\Models\Venue?$m->id:($m->venue_id??($m instanceof \App\Models\BookingPayment?$m->booking?->venue_id:null));
 self::record($venue,class_basename($m).($created?'.created':'.updated'),class_basename($m).':'.$m->getKey(),$changes);
 }
 public function deleted(Model $m):void {self::record($m instanceof \App\Models\Venue?$m->id:($m->venue_id??null),class_basename($m).'.deleted',class_basename($m).':'.$m->getKey());}
}
