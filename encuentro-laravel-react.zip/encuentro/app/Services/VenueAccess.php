<?php
namespace App\Services;
use App\Models\{Owner,Venue,VenueMember};
class VenueAccess {
 const PERMISSIONS=['reservations','payments','reports'];
 public function permissions(?Owner $actor,Venue $venue):array {if(!$actor||!$actor->activated)return [];if((int)$venue->owner_account_id===(int)$actor->id)return ['manage',...self::PERMISSIONS];return VenueMember::where('venue_id',$venue->id)->where('owner_id',$actor->id)->value('permissions')??[];}
 public function require(Venue $venue,string $permission):void {$actor=request()->user();abort_unless($actor instanceof Owner&&in_array($permission,$this->permissions($actor,$venue),true),403);}
}
