"""Check deployment archive permissions without extracting or starting containers.

Usage: python3 tests/package-permissions.py /path/to/encuentro-laravel-react.zip
Docker COPY retains source modes; root-owned application files must be readable
by the unprivileged runtime user. This does not replace a Docker build.
"""
import stat
import sys
from zipfile import ZipFile


def check_archive(path):
    errors = []
    with ZipFile(path) as archive:
        for entry in archive.infolist():
            mode = entry.external_attr >> 16
            if entry.is_dir():
                if mode & 0o005 != 0o005:
                    errors.append(f'{entry.filename}: directory is not traversable/readable')
            elif not mode & stat.S_IROTH:
                errors.append(f'{entry.filename}: file is not readable by runtime user')
            if mode & stat.S_IWOTH:
                errors.append(f'{entry.filename}: world writable')
            if entry.filename.rsplit('/', 1)[-1] == '.env':
                errors.append(f'{entry.filename}: private .env must not be shipped')
    return errors


if __name__ == '__main__':
    problems = check_archive(sys.argv[1])
    if problems:
        print('\n'.join(problems), file=sys.stderr)
        sys.exit(1)
    print('Archive permissions OK; no private .env or world-writable entries.')
