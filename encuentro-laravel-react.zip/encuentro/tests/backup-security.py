import importlib.util, json, os, pathlib, tarfile, tempfile, unittest, hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('backup',ROOT/'scripts/backup.py');backup=importlib.util.module_from_spec(spec);spec.loader.exec_module(backup)
class BackupSecurity(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.temp.name);self.key=self.root/'key';self.key.write_text('ab'*32+'\n');self.key.chmod(0o600)
 def tearDown(self):self.temp.cleanup()
 def test_roundtrip_and_tampering_is_rejected_before_decryption(self):
  source=self.root/'source';source.write_bytes(b'PRIVATE_APP_KEY\n'*100);encrypted=self.root/'encrypted';restored=self.root/'restored';backup.encrypt(source,encrypted,self.key);self.assertNotIn(b'PRIVATE_APP_KEY',encrypted.read_bytes());backup.decrypt(encrypted,restored,self.key);self.assertEqual(source.read_bytes(),restored.read_bytes());data=bytearray(encrypted.read_bytes());data[-3]^=1;encrypted.write_bytes(data)
  with self.assertRaises(ValueError):backup.decrypt(encrypted,self.root/'bad',self.key)
  self.assertFalse((self.root/'bad').exists())
 def test_wrong_key_and_public_key_file_are_rejected(self):
  source=self.root/'source';source.write_bytes(b'private');encrypted=self.root/'encrypted';backup.encrypt(source,encrypted,self.key);self.key.write_text('cd'*32+'\n')
  with self.assertRaises(ValueError):backup.decrypt(encrypted,self.root/'bad',self.key)
  self.key.chmod(0o644)
  with self.assertRaises(ValueError):backup.secret(self.key)
 def test_bundle_checks_hashes_and_does_not_extract_traversal(self):
  bad=self.root/'bad.tar'
  with tarfile.open(bad,'w') as out:
   member=tarfile.TarInfo('../outside');member.size=0;out.addfile(member)
  with self.assertRaises(ValueError):backup.validate_bundle(bad)
  self.assertFalse((self.root.parent/'outside').exists())
if __name__=='__main__':unittest.main(verbosity=2)
