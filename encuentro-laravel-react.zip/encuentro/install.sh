#!/usr/bin/env bash
# First install or upgrade. Secrets are created on the host, never during image build.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
umask 077
if [[ $# -gt 1 || ( $# -eq 1 && "$1" != '--prepare-only' ) ]]; then
    echo 'Opción no válida. Usa bash install.sh o bash install.sh --prepare-only.' >&2
    exit 1
fi
for required in artisan composer.json compose.yaml Dockerfile scripts/prepare-env.php; do
    if [[ ! -r "$required" ]]; then
        echo "Paquete incompleto: falta $required en $PWD. Extrae el proyecto completo antes de instalar." >&2
        exit 1
    fi
done
if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
    echo 'Necesitas Docker con Docker Compose para instalar la plataforma.' >&2
    exit 1
fi
# Prevent simultaneous migrations or recreations from two installer invocations.
if ! command -v flock >/dev/null 2>&1; then
    echo 'Instala util-linux (flock) antes de continuar.' >&2
    exit 1
fi
exec 9>.install.lock
if ! flock -n 9; then echo 'Ya hay otra instalación en curso en esta carpeta.' >&2; exit 1; fi
if command -v php >/dev/null 2>&1 && php -r 'exit(PHP_VERSION_ID >= 80300 ? 0 : 1);'; then
    php scripts/prepare-env.php
else
    docker run --rm --user "$(id -u):$(id -g)" \
        --mount "type=bind,src=$PWD,dst=/setup" --workdir /setup \
        --entrypoint php php:8.3-cli-alpine scripts/prepare-env.php
fi
# Compose and all application processes must use the same persisted file values.
unset APP_KEY REVERB_APP_KEY REVERB_APP_SECRET DB_PASSWORD DB_DATABASE DB_USERNAME
if [[ "${1:-}" == '--prepare-only' ]]; then
    echo 'Archivo .env preparado. Puedes revisar dominios y puertos antes de instalar.'
    exit 0
fi
# Pin the base configuration; inherited test overrides can hide the application.
compose=(docker compose --project-directory "$PWD" --env-file "$PWD/.env" -f "$PWD/compose.yaml")
echo 'Instalando con compose.yaml base; no se cargan COMPOSE_FILE ni archivos override adicionales.'
"${compose[@]}" config --quiet
"${compose[@]}" build --pull
if ! "${compose[@]}" run --rm --no-deps --workdir /var/www/html --entrypoint sh app -c 'test -r /var/www/html/artisan && test -r /var/www/html/vendor/autoload.php'; then
    echo 'La imagen app no contiene artisan o vendor/autoload.php legibles en /var/www/html. Revisa el contexto de construcción y los montajes antes de migrar.' >&2
    exit 1
fi
"${compose[@]}" up -d --wait db
"${compose[@]}" run --rm --no-deps --workdir /var/www/html app php /var/www/html/artisan migrate --force
"${compose[@]}" up -d --force-recreate
"${compose[@]}" exec -T --workdir /var/www/html app php /var/www/html/artisan optimize:clear
"${compose[@]}" exec -T --workdir /var/www/html app-owner php /var/www/html/artisan optimize:clear
"${compose[@]}" ps
echo 'Instalación terminada. Revisa los dominios de CUSTOMER_URL y OWNER_URL en .env y recarga el navegador.'
