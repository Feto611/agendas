# Operaciones y revisión de seguridad — 4 de noviembre de 2026

Esta revisión conserva el diseño crema y las funciones anteriores. Agrega una migración: `2026_11_04_000015_operations.php`. Es una revisión de código y pruebas locales, no una certificación de seguridad ni una inspección de tu servidor.

## Qué se agregó y dónde usarlo

En el panel del dueño, selecciona un local:

- **Operación y avisos:** habilita recordatorios y alertas. Los recordatorios de evento se generan dentro de las 24 horas previas; los de saldo entre uno y tres días antes. Se envían una vez por reserva, horario y tipo. Los avisos usan el correo configurado del local y están desactivados inicialmente. Las alertas van al titular, como máximo una por hora. El panel detecta pagos inciertos, correos con problemas, falta de señal de scheduler/realtime y respaldos antiguos cuando se habilita su supervisión.
- **Equipo y permisos:** agrega el correo de una cuenta de gestión activa y verificada. El administrador puede invitarla desde el servidor con `php artisan owners:invite correo@ejemplo.com`; el integrante termina su registro con su propia contraseña y verifica su correo. Permisos: agenda/cambios, registrar pagos manuales, reportes. Pagos o reportes incluyen acceso a agenda. Solo el titular modifica integrantes, configuración, pasarelas y secretos. Una cuenta puede colaborar en varios locales y tener sus propios locales. No comparte contraseñas.
- **Historial de acciones:** cambios de precios, horarios, reglas, estado de reservas, pagos, permisos y configuración. Se guardan actor, fecha y valores permitidos anteriores/nuevos. Los cambios de credenciales se registran como marcadores sin sus valores. La bitácora no modifica la contabilidad ni permite editar eventos desde la API. Un administrador de PostgreSQL sí podría alterarla: no se presenta como un registro externo inmutable.
- **Reportes:** periodo de hasta 366 días, totales de todos los eventos del periodo, cobros netos por fecha de registro, saldos, cancelaciones y ocupación. La ocupación mide horas de evento sobre horas de apertura; excluye preparación/limpieza y no equivale a rentabilidad. CSV limitado a 10,000 órdenes por descarga. Los reportes no son facturación fiscal.
- **Cambios de fecha:** el cliente consulta el nuevo precio, lo acepta y envía una solicitud. Su horario original sigue vigente; el horario solicitado no se bloquea. El titular o un empleado autorizado aprueba o rechaza. Al aprobar se bloquean local y reserva, y se revisan nuevamente precio, disponibilidad, pagos, anticipo y vigencia. Si cambian los datos, se pide una nueva propuesta. No se cobra ni devuelve dinero automáticamente. Los cambios que requieren reducir importes por debajo de lo pagado se remiten a atención manual. En horarios que cruzan medianoche, la hora del formulario corresponde al día seleccionado.

En **Mis reservas** aparecen contador del apartado, solicitud de cambio y **Descargar comprobante**. El comprobante es HTML privado con pagos y desglose: se puede abrir, imprimir y guardar como PDF desde el navegador. No es un PDF generado en servidor ni una factura fiscal. El apartado inicial dura 15 minutos; los plazos de pago se ajustan según proveedor y comienzo del evento.

## Actualizar

1. Conserva `.env`, APP_KEY, nombre del proyecto Compose y volúmenes. Respalda primero si ya hay datos reales.
2. Sustituye el código por el paquete completo y ejecuta desde la raíz:

```bash
bash install.sh
```

El instalador aplica la nueva migración y recrea los servicios. Usa el Compose base explícito; si tu despliegue utiliza archivos adicionales, incorpóralos de forma consciente. No ejecutes `down -v`, `migrate:fresh` ni generes otra APP_KEY.

3. Verifica `docker compose -f compose.yaml ps`. Scheduler y realtime-worker deben estar activos. Después de uno o dos minutos, revisa Operación y avisos.
4. Configura el correo de cada local y activa las preferencias que quieras usar.

## Respaldos automáticos cifrados

Se incluye `scripts/backup.py`, junto con unidades systemd de respaldo y supervisión. Se ejecutan en el **host Docker**, no desde una petición web. Requisitos: Python 3.10+, OpenSSL, Docker Compose, espacio suficiente y acceso al daemon Docker. La prueba aislada utiliza `postgres:17-alpine` sin puertos ni red, con límites de 1 CPU, 1 GB RAM y 2 GB de datos temporales. Si tu base supera ese tamaño, ajusta `ENCUENTRO_RESTORE_MEMORY` y `ENCUENTRO_RESTORE_DISK` en la configuración del servicio.

Cada respaldo incluye dump PostgreSQL, `storage/app` (fotografías y archivos privados) y `.env`. Se empaqueta, cifra con AES-256-CBC/PBKDF2 y autentica con HMAC-SHA256 antes de aceptar un descifrado. La clave aleatoria tiene archivo separado y permisos 600. No se incluye en el respaldo. El proceso descifra la copia, comprueba hashes y restaura el dump en un contenedor temporal antes de declarar éxito o borrar copias antiguas. Mantiene las últimas 14 copias exitosas. No tiene una orden que restaure directamente sobre producción.

Ejemplo usando la carpeta mostrada en tus capturas; ajústala si es distinta. Como administrador del host:

```bash
install -d -m 700 /etc/encuentro /var/backups/encuentro
python3 scripts/backup.py keygen /etc/encuentro/backup.key
```

Conserva otra copia privada de esa clave fuera del servidor. Sin ella no se puede recuperar el respaldo. Crea `/etc/encuentro-backup.conf`:

```ini
ENCUENTRO_PROJECT=/root/agendas/encuentro
ENCUENTRO_BACKUP_DIR=/var/backups/encuentro
ENCUENTRO_BACKUP_KEY=/etc/encuentro/backup.key
ENCUENTRO_RESTORE_MEMORY=1g
ENCUENTRO_RESTORE_DISK=2g
```

```bash
chmod 600 /etc/encuentro-backup.conf
cp deploy/encuentro-backup.service deploy/encuentro-backup.timer deploy/encuentro-watch.service deploy/encuentro-watch.timer /etc/systemd/system/
systemctl daemon-reload
systemctl start encuentro-backup.service
journalctl -u encuentro-backup.service -n 50 --no-pager
```

Solo tras una prueba correcta:

```bash
systemctl enable --now encuentro-backup.timer encuentro-watch.timer
systemctl list-timers encuentro-backup.timer encuentro-watch.timer
```

El respaldo se programa diariamente hacia las 03:00, con hasta 15 minutos de dispersión, según la zona horaria del host. Watch comprueba cada cinco minutos aunque se detenga el scheduler. En `.env` activa `BACKUP_MONITOR_ENABLED=true` y deja `BACKUP_MAX_HOURS=30`, luego recrea los contenedores. No se habilitan temporizadores en tu servidor por descargar este archivo.

Para comprobar o recuperar una copia privada sin modificar producción:

```bash
python3 scripts/backup.py verify /var/backups/encuentro/ARCHIVO.enc --key-file /etc/encuentro/backup.key
python3 scripts/backup.py unpack /var/backups/encuentro/ARCHIVO.enc --key-file /etc/encuentro/backup.key --output /var/backups/recuperacion-nueva
```

`unpack` exige una carpeta nueva. Genera `database.dump`, `storage.tar`, `environment.env` y el manifiesto con permisos privados. Para recuperar el servicio completo, utiliza un entorno aislado: restaura con `pg_restore --no-owner --no-acl --exit-on-error --single-transaction` en una base nueva, recupera `storage/app`, coloca `environment.env` como `.env` conservando APP_KEY, ajusta el destino de la nueva base y prueba antes de sustituir producción. Nunca restaures copias no confiables.

### Límites que debes conocer

- Las copias son locales. Programa además una copia fuera del servidor; perder el disco del host perdería esos respaldos. No se ha conectado una cuenta externa sin tus datos.
- El dump es consistente a nivel PostgreSQL. Dump y archivos no son una instantánea atómica conjunta; evita subir/eliminar fotos durante la ventana o complementa con instantáneas coordinadas de Proxmox.
- Se comprueban archivos del respaldo y restauración SQL. Esto no sustituye un ensayo funcional completo de recuperación de la plataforma.
- Un proveedor de correo caído puede impedir enviar sus propias alertas. Para detectar caída total de Docker, host o red, utiliza un monitor externo como tu Gatus y revisa fallos del temporizador en journalctl. No puede garantizarse una alerta desde un servidor totalmente apagado.

## Hallazgos de seguridad y correcciones

| Hallazgo | Cambio | Comprobación |
|---|---|---|
| Límite de cinco apartados calculado bajo un bloqueo de local: solicitudes del mismo cliente en locales distintos podían rebasarlo | Bloqueo del cliente antes del local | Carrera PostgreSQL de ocho peticiones: cinco aceptadas y tres rechazadas |
| Un intento incierto vencido podía dejar de bloquear un nuevo checkout | No crear otro cargo mientras exista un intento creating/unknown vencido sin resolver | Prueba: ningún HTTP nuevo y un solo intento conservado |
| Dependencias Symfony con seis avisos publicados recientemente | http-foundation, http-kernel y routing actualizados a 7.4.23; dependencias compatibles actualizadas en lock | Composer audit sin avisos tras actualización |
| Contraseñas sin límite explícito de longitud en alta y recuperación | Máximo 72 bytes para el algoritmo bcrypt, comprobando también caracteres multibyte antes del hash | Validación de entrada excesiva |
| Fotografías limitadas por bytes pero sin límite explícito de dimensiones | Máximo 6000 × 6000 además del límite de 5 MB | Validación del servidor; archivos privados y mimes restringidos se conservan |
| Política CORS sin configuración explícita del proyecto | API de mismo origen, sin comodín de orígenes | Petición desde origen ajeno no recibe permiso wildcard |

No se ha demostrado que los avisos Symfony fueran explotables en este despliegue concreto. Se actualizan preventivamente los componentes afectados, en lugar de inferir seguridad por no utilizar una función específica.

La revisión también inspeccionó separación de portales, autorización por propietario, acceso a reservas/archivos, SQL parametrizado, XSS/escape, CSRF, URLs externas/SSRF, firmas de webhooks, importe/moneda/receptor del pago, idempotencia, cifrado de credenciales, recuperación de cuentas y sesiones. Las pruebas anteriores se conservan; las nuevas verifican además aislamiento de empleados, revocación, precio aceptado, conflictos de cambios, comprobantes privados, bitácora sin secretos, avisos deduplicados y respaldos alterados. Los correos y avisos pendientes con horario anterior se cancelan o marcan para revisión; no se repiten automáticamente envíos inciertos.

## Fuentes y verificaciones reproducibles

- Laravel: [autorización](https://laravel.com/docs/12.x/authorization), [transacciones](https://laravel.com/docs/12.x/database#database-transactions), [transacciones y colas](https://laravel.com/docs/12.x/queues#jobs-and-database-transactions).
- PostgreSQL: [pg_dump](https://www.postgresql.org/docs/17/app-pgdump.html), [pg_restore](https://www.postgresql.org/docs/17/app-pgrestore.html).
- Symfony: [aviso de rutas normalizadas](https://github.com/symfony/symfony/security/advisories/GHSA-3h27-hjv7-fqjx), avisos de proxies, generación de URL, fragmentos, HEAD y routing registrados por Composer en los resultados de auditoría.

```bash
php artisan test
npm run test:ui
npm run build
python3 tests/backup-security.py
python3 tests/installer-integration.py
composer audit --locked
npm audit --package-lock-only
# Solo base desechable de pruebas definida en este Compose:
docker compose -f compose.concurrency.yaml up --build --abort-on-container-exit --exit-code-from concurrency
```

Consulta los resultados exactos de esta revisión en `audit/operations-summary.json`. El entorno local utiliza PHP 8.3.6 para pruebas funcionales y PostgreSQL 16.15 para concurrencia/restauración nativa; no certifica PHP parcheado. El despliegue conserva PHP 8.3-FPM con la comprobación de versión mínima del Dockerfile y PostgreSQL 17. No hubo Docker disponible para construir la imagen ni ejecutar el temporizador o la prueba del contenedor PostgreSQL 17. No se hicieron cobros, envíos reales ni cambios en tu servidor.

## Pendiente de verificar en el despliegue

No se inspeccionaron reglas de Cloudflare, túnel, certificados, HSTS efectivo, firewall, puertos expuestos, permisos del host/daemon, cifrado del disco PostgreSQL ni destino externo de respaldos. Los datos personales de reservas no se convirtieron a cifrado de columna; las credenciales y los nuevos payloads privados sí usan cifrado de aplicación. Revisa esos controles del servidor antes de afirmar que toda la base está cifrada. Tampoco se realizaron pagos ni envíos de correo reales.
