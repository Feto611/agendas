<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{AuthController,VenueController,BookingController,GeocodeController,ChatController,MediaController,SocialController,OwnerPaymentController,GatewayController,CheckoutController,PaymentWebhookController};
Route::prefix('api')->group(function(){
 Route::post('/email/verify',[\App\Http\Controllers\EmailVerificationController::class,'confirm'])->middleware('throttle:10,1');
 Route::post('/email/send',[\App\Http\Controllers\EmailVerificationController::class,'send'])->middleware('auth');
 Route::post('/password/forgot',[\App\Http\Controllers\PasswordRecoveryController::class,'forgot'])->middleware('throttle:5,1');
 Route::post('/password/reset',[\App\Http\Controllers\PasswordRecoveryController::class,'reset'])->middleware('throttle:10,1');
 Route::get('/platform-branding',[\App\Http\Controllers\PlatformBrandingController::class,'show']);
 Route::get('/platform-branding/images/{kind}',[\App\Http\Controllers\PlatformBrandingController::class,'image']);

 Route::match(['get','post'],'/meta/webhooks/{venue}/{channel}',\App\Http\Controllers\MetaWebhookController::class)->middleware(['portal:client','throttle:120,1']);
 Route::post('/realtime/auth',\App\Http\Controllers\RealtimeAuthController::class)->middleware('throttle:120,1');
 Route::get('/media/branding/{asset}',[\App\Http\Controllers\DesignAssetController::class,'image']);
 Route::get('/me',[AuthController::class,'me']);Route::get('/media/photos/{photo}',[MediaController::class,'photo']);
 Route::get('/venues',[VenueController::class,'listing']);Route::get('/venues/{venue}',[VenueController::class,'show']);Route::get('/venues/{venue}/availability',[BookingController::class,'availability'])->middleware('throttle:30,1');Route::post('/venues/{venue}/quote',[BookingController::class,'quote'])->middleware('throttle:60,1');Route::post('/venues/{venue}/chat',[ChatController::class,'send'])->middleware(['portal:client','throttle:20,1']);
 Route::post('/payments/webhooks/{venue}/{provider}/{account?}',PaymentWebhookController::class)->middleware(['portal:client','throttle:120,1']);
 Route::middleware(['portal:client','auth:web'])->group(function(){Route::post('/bookings/{booking}/reschedule',[\App\Http\Controllers\OperationsController::class,'requestChange'])->middleware(['email.confirmed','throttle:5,1']);Route::get('/bookings/{booking}/receipt',[\App\Http\Controllers\OperationsController::class,'receipt']);});
 Route::middleware('portal:client')->group(function(){Route::post('/register',[AuthController::class,'register'])->middleware('throttle:5,1');Route::post('/login',[AuthController::class,'login']);Route::post('/logout',[AuthController::class,'logout'])->middleware('auth:web');Route::middleware('auth:web')->group(function(){Route::post('/venues/{venue}/bookings',[BookingController::class,'store'])->middleware(['email.confirmed','throttle:10,1']);Route::get('/bookings',[BookingController::class,'mine']);Route::post('/venues/{venue}/conversation-link',[\App\Http\Controllers\MessagingController::class,'link'])->middleware('throttle:5,1');Route::get('/venues/{venue}/conversation-history',[\App\Http\Controllers\MessagingController::class,'history']);Route::post('/bookings/{booking}/cancel',[BookingController::class,'cancel']);Route::get('/bookings/{booking}/payment-options',[CheckoutController::class,'options']);Route::post('/bookings/{booking}/checkout',[CheckoutController::class,'start'])->middleware(['email.confirmed','throttle:checkout']);Route::post('/checkout/{attempt}/sync',[CheckoutController::class,'sync'])->middleware('throttle:payment-actions');Route::get('/checkout/{attempt}',[CheckoutController::class,'show']);Route::post('/checkout/{attempt}/card',[CheckoutController::class,'card'])->middleware(['email.confirmed','throttle:payment-actions']);Route::post('/checkout/{attempt}/capture',[CheckoutController::class,'capture'])->middleware(['email.confirmed','throttle:payment-actions']);Route::post('/checkout/{attempt}/reconcile',[CheckoutController::class,'reconcile'])->middleware('throttle:20,1');});});
 Route::middleware('portal:owner')->group(function(){Route::post('/owner-auth/login',[AuthController::class,'ownerLogin']);Route::post('/owner-auth/register',[AuthController::class,'ownerRegister'])->middleware('throttle:5,1');Route::post('/owner-auth/logout',[AuthController::class,'logout'])->middleware('auth:owner');Route::middleware('auth:owner')->group(function(){
 Route::get('/owner/venues/{venue}/operations',[\App\Http\Controllers\OperationsController::class,'show']);
 Route::put('/owner/venues/{venue}/operations',[\App\Http\Controllers\OperationsController::class,'save']);
 Route::get('/owner/venues/{venue}/audit',[\App\Http\Controllers\OperationsController::class,'audit']);
 Route::get('/owner/venues/{venue}/team',[\App\Http\Controllers\OperationsController::class,'team']);
 Route::put('/owner/venues/{venue}/team',[\App\Http\Controllers\OperationsController::class,'teamSave'])->middleware('throttle:10,1');
 Route::delete('/owner/venues/{venue}/team/{member}',[\App\Http\Controllers\OperationsController::class,'teamDelete']);
 Route::get('/owner/venues/{venue}/reschedule',[\App\Http\Controllers\OperationsController::class,'requests']);
 Route::post('/owner/venues/{venue}/reschedule/{change}',[\App\Http\Controllers\OperationsController::class,'decide'])->middleware('throttle:20,1');
 Route::get('/owner/venues/{venue}/report',[\App\Http\Controllers\OperationsController::class,'report'])->middleware('throttle:30,1');
 Route::get('/owner/venues/{venue}/report.csv',[\App\Http\Controllers\OperationsController::class,'csv'])->middleware('throttle:5,1');
 Route::get('/owner/bookings/{booking}/receipt',[\App\Http\Controllers\OperationsController::class,'receipt']);
 foreach(['/owner/email-designs','/owner/venues/{venue}/email-designs'] as $path){
  Route::get($path,[\App\Http\Controllers\EmailDesignController::class,'show']);
  Route::put($path,[\App\Http\Controllers\EmailDesignController::class,'save']);
  Route::post($path.'/preview',[\App\Http\Controllers\EmailDesignController::class,'preview'])->middleware('throttle:120,1');
 }
 Route::middleware(\App\Http\Middleware\DomainFeatureEnabled::class)->group(function(){
 Route::get('/owner/sites/settings',[\App\Http\Controllers\VenueDomainController::class,'general']);
 Route::put('/owner/sites/settings',[\App\Http\Controllers\VenueDomainController::class,'saveGeneral']);
 Route::get('/owner/sites/venues',[\App\Http\Controllers\VenueDomainController::class,'venues']);
 Route::get('/owner/venues/{venue}/site',[\App\Http\Controllers\VenueDomainController::class,'show']);
 Route::put('/owner/venues/{venue}/site',[\App\Http\Controllers\VenueDomainController::class,'save']);
 Route::post('/owner/venues/{venue}/site/verify/{kind}',[\App\Http\Controllers\VenueDomainController::class,'verify'])->middleware('throttle:6,1');
 });
 Route::get('/owner/platform-branding/readiness',[\App\Http\Controllers\PlatformBrandingController::class,'readiness']);
 Route::put('/owner/platform-branding',[\App\Http\Controllers\PlatformBrandingController::class,'save']);
 Route::post('/owner/platform-branding/images/{kind}',[\App\Http\Controllers\PlatformBrandingController::class,'upload'])->middleware('throttle:20,1');
 Route::delete('/owner/platform-branding/images/{kind}',[\App\Http\Controllers\PlatformBrandingController::class,'destroy']);

 Route::get('/owner/venues/{venue}/design/assets',[\App\Http\Controllers\DesignAssetController::class,'index']);Route::post('/owner/venues/{venue}/design/assets',[\App\Http\Controllers\DesignAssetController::class,'store'])->middleware('throttle:20,1');Route::delete('/owner/venues/{venue}/design/assets/{asset}',[\App\Http\Controllers\DesignAssetController::class,'destroy']);
 Route::get('/owner/venues/{venue}/design',[\App\Http\Controllers\DesignController::class,'show']);Route::put('/owner/venues/{venue}/design',[\App\Http\Controllers\DesignController::class,'save']);
 Route::get('/owner/venues/{venue}/messaging',[\App\Http\Controllers\MessagingController::class,'connections']);Route::put('/owner/venues/{venue}/messaging/{channel}',[\App\Http\Controllers\MessagingController::class,'save']);Route::get('/owner/venues/{venue}/inbox',[\App\Http\Controllers\MessagingController::class,'inbox']);Route::get('/owner/venues/{venue}/inbox/{thread}',[\App\Http\Controllers\MessagingController::class,'messages']);Route::patch('/owner/venues/{venue}/inbox/{thread}',[\App\Http\Controllers\MessagingController::class,'pause']);
 Route::get('/owner/venues/{venue}/mail',[\App\Http\Controllers\MailSettingsController::class,'show']);Route::put('/owner/venues/{venue}/mail',[\App\Http\Controllers\MailSettingsController::class,'save']);Route::get('/owner/venues/{venue}/mail/history',[\App\Http\Controllers\MailSettingsController::class,'history']);Route::post('/owner/venues/{venue}/mail/retry/{notification}',[\App\Http\Controllers\MailSettingsController::class,'retry'])->middleware('throttle:5,1');
 Route::get('/owner/defaults',[VenueController::class,'defaults']);Route::get('/owner/venues',[VenueController::class,'index']);Route::post('/owner/venues',[VenueController::class,'store']);Route::put('/owner/venues/{venue}',[VenueController::class,'update']);Route::get('/owner/venues/{venue}/bookings',[VenueController::class,'bookings']);Route::post('/owner/geocode',GeocodeController::class)->middleware('throttle:60,1');
 Route::post('/owner/venues/{venue}/photos',[MediaController::class,'upload'])->middleware('throttle:20,1');Route::patch('/owner/venues/{venue}/photos/{photo}',[MediaController::class,'update']);Route::delete('/owner/venues/{venue}/photos/{photo}',[MediaController::class,'destroy']);Route::post('/owner/venues/{venue}/reviews',[MediaController::class,'review']);Route::patch('/owner/venues/{venue}/reviews/{review}',[MediaController::class,'reviewVisibility']);
 Route::get('/owner/venues/{venue}/instagram',[SocialController::class,'status']);Route::post('/owner/venues/{venue}/instagram',[SocialController::class,'connect']);Route::delete('/owner/venues/{venue}/instagram',[SocialController::class,'disconnect']);Route::get('/owner/venues/{venue}/instagram/preview',[SocialController::class,'preview'])->middleware('throttle:3,1');Route::post('/owner/venues/{venue}/instagram/import',[SocialController::class,'import'])->middleware('throttle:3,1');Route::post('/owner/venues/{venue}/bookings/{booking}/payments',[OwnerPaymentController::class,'store'])->middleware('throttle:15,1');Route::get('/owner/venues/{venue}/gateways/{provider}/diagnostics',[GatewayController::class,'diagnostics']);Route::get('/owner/venues/{venue}/gateways',[GatewayController::class,'index']);Route::put('/owner/venues/{venue}/gateways/{provider}',[GatewayController::class,'update']);
 });});
});
Route::get('/{path?}',function(\Illuminate\Http\Request $r){$path=$r->path();if(config('portal.kind')==='client'&&(str_starts_with($path,'owner')||str_starts_with($path,'gestion')))abort(404);if(config('portal.kind')==='owner'&&!in_array($path,['/','gestion','gestion/identidad'],true))abort(404);return response()->view('app')->header('Cache-Control','no-store, private');})->where('path','^(?!api(?:/|$)).*')->name('login');
