<?php
return ['backup_expected'=>env('BACKUP_MONITOR_ENABLED',false),'backup_max_hours'=>(int)env('BACKUP_MAX_HOURS',30)];
