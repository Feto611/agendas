<?php
return ['paths'=>['api/*'],'allowed_methods'=>['GET','POST','PUT','PATCH','DELETE','OPTIONS'],'allowed_origins'=>[],'allowed_origins_patterns'=>[],'allowed_headers'=>['Content-Type','X-CSRF-TOKEN','X-XSRF-TOKEN','X-Requested-With'],'exposed_headers'=>[],'max_age'=>0,'supports_credentials'=>false];
