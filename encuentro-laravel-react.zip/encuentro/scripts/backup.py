#!/usr/bin/env python3
"""Encrypted Docker backup + isolated restore drill. No production restore command.
Requires Python 3.10+, OpenSSL and Docker Compose. Run on the Docker host.
"""
import argparse, contextlib, datetime, hashlib, hmac, io, json, os, pathlib, re, secrets, shutil, stat, subprocess, tarfile, tempfile
MAGIC=b'ENCUENTRO-BACKUP-1\n'

def run(args, **kwargs):
    return subprocess.run(args, check=True, timeout=kwargs.pop('timeout',600), **kwargs)

def secret(path):
    p=pathlib.Path(path)
    if p.is_symlink() or not p.is_file() or p.stat().st_mode & 0o077:
        raise ValueError('La clave debe ser un archivo privado (chmod 600), sin enlaces simbólicos.')
    data=p.read_bytes().strip()
    if not re.fullmatch(rb'[a-f0-9]{64}',data):raise ValueError('Genera la clave con el subcomando keygen.')
    return data

def tag(key, path):
    digest=hmac.new(hmac.digest(key,b'encuentro-backup-auth-v1','sha256'),MAGIC,'sha256')
    with open(path,'rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.digest()

def encrypt(source, target, keyfile):
    key=secret(keyfile)
    with tempfile.TemporaryDirectory(prefix='encuentro-encrypt-') as work:
        cipher=pathlib.Path(work)/'cipher'
        run(['openssl','enc','-aes-256-cbc','-salt','-pbkdf2','-iter','200000','-pass','file:'+str(keyfile),'-in',str(source),'-out',str(cipher)])
        with open(target,'xb') as out,open(cipher,'rb') as data:
            out.write(MAGIC+tag(key,cipher));shutil.copyfileobj(data,out)
        os.chmod(target,0o600)

def decrypt(source,target,keyfile):
    key=secret(keyfile)
    with tempfile.TemporaryDirectory(prefix='encuentro-decrypt-') as work:
        cipher=pathlib.Path(work)/'cipher'
        with open(source,'rb') as stream,open(cipher,'wb') as out:
            if stream.read(len(MAGIC))!=MAGIC:raise ValueError('Formato de respaldo no válido.')
            expected=stream.read(32);shutil.copyfileobj(stream,out)
        if not hmac.compare_digest(expected,tag(key,cipher)):raise ValueError('Clave incorrecta o respaldo alterado: no se descifra.')
        run(['openssl','enc','-d','-aes-256-cbc','-pbkdf2','-iter','200000','-pass','file:'+str(keyfile),'-in',str(cipher),'-out',str(target)])

def sha(path):
    value=hashlib.sha256()
    with open(path,'rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
    return value.hexdigest()

def validate_bundle(bundle):
    # Only inspect/read named files. Never extract arbitrary paths or links.
    with tarfile.open(bundle,'r') as archive:
        members=archive.getmembers();names={m.name for m in members}
        if names!={'database.dump','storage.tar','environment.env','manifest.json'} or len(members)!=4 or any(not m.isfile() for m in members):
            raise ValueError('Contenido de respaldo inesperado.')
        manifest=json.load(archive.extractfile('manifest.json'))
        for name in ['database.dump','storage.tar','environment.env']:
            digest=hashlib.sha256()
            with archive.extractfile(name) as stream:
                for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
            if digest.hexdigest()!=manifest['sha256'][name]:raise ValueError('Checksum incorrecto: '+name)
        with tarfile.open(fileobj=archive.extractfile('storage.tar'),mode='r|') as storage:
            for member in storage:
                name=pathlib.PurePosixPath(member.name)
                if name.is_absolute() or '..' in name.parts or not (member.isfile() or member.isdir()):raise ValueError('Ruta o enlace no permitido en storage.')
        return manifest

def drill(bundle):
    validate_bundle(bundle)
    name='encuentro-restore-'+secrets.token_hex(6)
    memory=os.environ.get('ENCUENTRO_RESTORE_MEMORY','1g');disk=os.environ.get('ENCUENTRO_RESTORE_DISK','2g')
    if not all(re.fullmatch(r'[1-9][0-9]*(m|g)',value) for value in [memory,disk]):raise ValueError('Límites de restauración no válidos.')
    try:
        run(['docker','run','--detach','--name',name,'--network','none','--memory',memory,'--cpus','1','--tmpfs','/var/lib/postgresql/data:rw,size='+disk,'-e','POSTGRES_HOST_AUTH_METHOD=trust','postgres:17-alpine'],stdout=subprocess.DEVNULL)
        import time
        for attempt in range(60):
            if subprocess.run(['docker','exec',name,'pg_isready','-U','postgres'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10).returncode==0:break
            time.sleep(1)
        else:raise RuntimeError('No inició PostgreSQL de restauración.')
        run(['docker','exec',name,'createdb','-U','postgres','restore_check'])
        with tarfile.open(bundle) as archive,archive.extractfile('database.dump') as dump:
            process=subprocess.Popen(['docker','exec','-i',name,'pg_restore','-U','postgres','--no-owner','--no-acl','--exit-on-error','--single-transaction','-d','restore_check'],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL)
            try:shutil.copyfileobj(dump,process.stdin);process.stdin.close();code=process.wait(timeout=600)
            except BaseException:process.kill();process.wait();raise
            if code:raise RuntimeError('Falló la restauración de prueba.')
        run(['docker','exec',name,'psql','-U','postgres','-d','restore_check','-v','ON_ERROR_STOP=1','-c','SELECT count(*) FROM migrations; SELECT count(*) FROM bookings;'],stdout=subprocess.DEVNULL)
    finally:
        subprocess.run(['docker','rm','-f',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30)

def backup(project,destination,keyfile,keep):
    project=pathlib.Path(project).resolve();destination=pathlib.Path(destination).resolve()
    if destination==project or project in destination.parents:raise ValueError('Guarda respaldos fuera de la carpeta del proyecto.')
    secret(keyfile);destination.mkdir(parents=True,exist_ok=True);os.chmod(destination,0o700)
    import fcntl
    with open(destination/'.backup.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        compose=['docker','compose','--project-directory',str(project),'--env-file',str(project/'.env'),'-f',str(project/'compose.yaml')]
        now=datetime.datetime.now(datetime.timezone.utc).isoformat()
        with tempfile.TemporaryDirectory(prefix='encuentro-backup-') as temp:
            work=pathlib.Path(temp)
            with open(work/'database.dump','wb') as dump:run(compose+['exec','-T','db','sh','-c','exec pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc --no-owner --no-acl'],stdout=dump)
            with open(work/'storage.tar','wb') as storage:run(compose+['run','--rm','--no-deps','--entrypoint','tar','app','-C','/var/www/html/storage/app','-cf','-','.'],stdout=storage)
            shutil.copyfile(project/'.env',work/'environment.env')
            files=['database.dump','storage.tar','environment.env'];manifest={'version':1,'created_at':now,'sha256':{name:sha(work/name) for name in files}}
            (work/'manifest.json').write_text(json.dumps(manifest))
            bundle=work/'bundle.tar'
            with tarfile.open(bundle,'w') as archive:
                for name in files+['manifest.json']:archive.add(work/name,arcname=name,recursive=False)
            # Verify the full encryption roundtrip and restore the decrypted dump.
            encrypted=work/'verified.enc';encrypt(bundle,encrypted,keyfile)
            restored=work/'roundtrip.tar';decrypt(encrypted,restored,keyfile);drill(restored)
            stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')
            target=destination/('encuentro-'+stamp+'-'+secrets.token_hex(3)+'.enc')
            shutil.move(encrypted,target)
            status=json.dumps({'completed_at':now,'restored_test':True})
            run(compose+['exec','-T','app','php','/var/www/html/artisan','operations:backup-status'],input=status.encode())
            for old in sorted(destination.glob('encuentro-*.enc'),key=lambda p:p.stat().st_mtime,reverse=True)[keep:]:old.unlink()
            print('Respaldo cifrado y restauración aislada correctos:',target)

def main():
    os.umask(0o077)
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    key=sub.add_parser('keygen');key.add_argument('path')
    back=sub.add_parser('backup');back.add_argument('--project',required=True);back.add_argument('--destination',required=True);back.add_argument('--key-file',required=True);back.add_argument('--keep',type=int,default=14)
    check=sub.add_parser('verify');check.add_argument('file');check.add_argument('--key-file',required=True)
    unpack=sub.add_parser('unpack');unpack.add_argument('file');unpack.add_argument('--key-file',required=True);unpack.add_argument('--output',required=True)
    args=parser.parse_args()
    if args.command=='keygen':
        with open(args.path,'x') as stream:stream.write(secrets.token_hex(32)+'\n')
        os.chmod(args.path,0o600);print('Clave generada. Conserva otra copia privada fuera del servidor.')
    elif args.command=='backup':
        if not 1<=args.keep<=365:parser.error('--keep debe estar entre 1 y 365')
        backup(args.project,args.destination,args.key_file,args.keep)
    elif args.command=='unpack':
        destination=pathlib.Path(args.output);destination.mkdir(mode=0o700,parents=True,exist_ok=False)
        try:
            with tempfile.TemporaryDirectory() as work:
                bundle=pathlib.Path(work)/'bundle.tar';decrypt(args.file,bundle,args.key_file);validate_bundle(bundle)
                with tarfile.open(bundle) as archive:
                    for name in ['database.dump','storage.tar','environment.env','manifest.json']:
                        with archive.extractfile(name) as source,open(destination/name,'xb') as out:shutil.copyfileobj(source,out)
                        os.chmod(destination/name,0o600)
            print('Copia privada recuperada en',destination,'. No se ha modificado producción.')
        except BaseException:
            shutil.rmtree(destination);raise
    else:
        with tempfile.TemporaryDirectory() as work:
            bundle=pathlib.Path(work)/'bundle.tar';decrypt(args.file,bundle,args.key_file);drill(bundle);print('Integridad y restauración aislada correctas.')
if __name__=='__main__':main()
