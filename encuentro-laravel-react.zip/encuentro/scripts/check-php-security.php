<?php

// Run during image build and after deployment; never expose as a public endpoint.
$errors = [];
if (PHP_VERSION_ID < 80336 || PHP_VERSION_ID >= 80400) {
    $errors[] = 'Se requiere PHP 8.3.36 o posterior de la rama 8.3.';
}
if (filter_var(ini_get('session.upload_progress.enabled'), FILTER_VALIDATE_BOOLEAN)) {
    $errors[] = 'session.upload_progress.enabled debe estar desactivado.';
}
if ($errors !== []) {
    fwrite(STDERR, implode(PHP_EOL, $errors).PHP_EOL);
    exit(1);
}
echo 'PHP '.PHP_VERSION.'; session.upload_progress.enabled=Off'.PHP_EOL;
